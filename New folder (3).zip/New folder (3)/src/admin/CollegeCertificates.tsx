import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast, { Toaster } from 'react-hot-toast';

const API_BASE = "http://192.168.1.7/pcsCertificate/backend/public";

type CollegeCertificate = {
  id: number;
  studentName: string;
  collegeName: string;
  certificateTitle: string;
  fromDate: string;
  toDate: string;
  date: string;
  serialNumber: string;
};

const CollegeCertificates: React.FC = () => {
  const navigate = useNavigate();
  const [colleges, setColleges] = useState<string[]>([]);
  const [selectedCollege, setSelectedCollege] = useState<string>('');
  const [certificates, setCertificates] = useState<CollegeCertificate[]>([]);
  const [loading, setLoading] = useState(false);
  const [collegesLoading, setCollegesLoading] = useState(true);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    fetchColleges();
  }, []);

  const fetchColleges = async () => {
    try {
      const res = await fetch(`${API_BASE}/colleges.php`);
      if (!res.ok) throw new Error('Failed to load colleges');
      const data = await res.json();
      setColleges(data);
    } catch (e) {
      toast.error('Failed to load college list');
    } finally {
      setCollegesLoading(false);
    }
  };

  const fetchCertificates = async (college: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/college_certificates.php?collegeName=${encodeURIComponent(college)}`);
      if (!res.ok) throw new Error('Failed to load certificates');
      const data = await res.json();
      setCertificates(data);
    } catch (e) {
      toast.error('Failed to load certificates');
      setCertificates([]);
    } finally {
      setLoading(false);
    }
  };

  const handleCollegeSelect = (college: string) => {
    setSelectedCollege(college);
    setIsDropdownOpen(false);
    if (college) {
      fetchCertificates(college);
    } else {
      setCertificates([]);
    }
  };

  const handleView = (cert: CollegeCertificate) => {
    if (cert.serialNumber) {
      window.open(`/verify/${cert.serialNumber}`, '_blank');
    } else {
      toast.error('No serial number found for this certificate');
    }
  };

  const formatDate = (dateStr: string): string => {
    if (!dateStr) return '-';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}.${parts[1]}.${parts[0]}`;
    return dateStr;
  };

  return (
    <div className="p-6">
      <Toaster />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-800">College Certificates</h1>
        <p className="text-sm text-slate-500 mt-1">Select a college to view all issued certificates</p>
      </div>

      {/* College Dropdown */}
      <div className="mb-6 relative">
        <label className="block text-xs font-bold text-slate-600 uppercase tracking-wider mb-2">
          Select College
        </label>
        <button
          type="button"
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          disabled={collegesLoading}
          className="w-full max-w-md flex items-center justify-between rounded-lg border border-slate-300 bg-white px-4 py-3 text-sm font-medium text-slate-700 shadow-sm hover:border-slate-400 focus:border-blue-500 focus:outline-none transition-colors"
        >
          <span className={selectedCollege ? 'text-slate-800' : 'text-slate-400'}>
            {collegesLoading
              ? 'Loading colleges...'
              : selectedCollege
              ? selectedCollege
              : '-- Select a College --'}
          </span>
          <svg className={`w-4 h-4 text-slate-400 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>

        {isDropdownOpen && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setIsDropdownOpen(false)} />
            <div className="absolute top-full left-0 mt-1 w-full max-w-md max-h-64 overflow-y-auto rounded-lg border border-slate-200 bg-white shadow-xl z-20 py-1">
              <button
                onClick={() => handleCollegeSelect('')}
                className={`w-full text-left px-4 py-2.5 text-sm hover:bg-slate-100 transition-colors ${
                  selectedCollege === '' ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-slate-700'
                }`}
              >
                -- All Colleges --
              </button>
              {colleges.map((college) => (
                <button
                  key={college}
                  onClick={() => handleCollegeSelect(college)}
                  className={`w-full text-left px-4 py-2.5 text-sm hover:bg-slate-100 transition-colors ${
                    selectedCollege === college ? 'bg-blue-50 text-blue-600 font-semibold' : 'text-slate-700'
                  }`}
                >
                  {college}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Total Count Card */}
      {selectedCollege && !loading && (
        <div className="mb-6 bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-5 text-white shadow-lg">
          <p className="text-sm font-medium text-blue-100 uppercase tracking-wider">Total Certificates</p>
          <p className="text-4xl font-bold mt-1">{certificates.length}</p>
          <p className="text-sm text-blue-200 mt-1">{selectedCollege}</p>
        </div>
      )}

      {/* Results */}
      {!selectedCollege ? (
        <div className="text-center py-12 text-slate-400 text-sm">
          <svg className="w-12 h-12 mx-auto mb-3 text-slate-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
          </svg>
          Select a college from the dropdown to view certificates
        </div>
      ) : loading ? (
        <div className="text-center py-12 text-slate-500 text-sm">Loading certificates...</div>
      ) : certificates.length === 0 ? (
        <div className="text-center py-12 text-slate-400 text-sm">
          No certificates found for this college
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="px-5 py-3 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
            <p className="text-sm font-semibold text-slate-700">
              {selectedCollege}
            </p>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-slate-700">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">ID</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">Student Name</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">Certificate</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">From</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">To</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white">
                {certificates.map((cert) => (
                  <tr key={cert.id} className="hover:bg-slate-50 border-b border-slate-100 last:border-0 transition-colors">
                    <td className="px-4 py-3 text-slate-500">{cert.id}</td>
                    <td className="px-4 py-3 font-medium text-slate-800">{cert.studentName}</td>
                    <td className="px-4 py-3">
                      <span className="bg-blue-50 text-blue-700 px-2 py-0.5 rounded text-xs font-medium">
                        {cert.certificateTitle}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-600">{formatDate(cert.fromDate)}</td>
                    <td className="px-4 py-3 text-slate-600">{formatDate(cert.toDate)}</td>
                    <td className="px-4 py-3 text-slate-500">{formatDate(cert.date)}</td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => handleView(cert)}
                        disabled={!cert.serialNumber}
                        className="text-xs bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors text-white px-3 py-1.5 rounded font-medium"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default CollegeCertificates;
