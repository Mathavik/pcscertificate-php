-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2026 at 12:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `certificate`
--

-- --------------------------------------------------------

--
-- Table structure for table `certificates`
--

CREATE TABLE `certificates` (
  `id` int(10) UNSIGNED NOT NULL,
  `studentName` varchar(255) NOT NULL,
  `collegeName` varchar(255) DEFAULT NULL,
  `fromDate` date DEFAULT NULL,
  `toDate` date DEFAULT NULL,
  `date` date DEFAULT NULL,
  `certificateTitle` varchar(255) NOT NULL,
  `projectTitle` varchar(255) DEFAULT NULL,
  `certificateContent` text DEFAULT NULL,
  `signatoryTitle` varchar(255) DEFAULT NULL,
  `attendanceTotalDays` int(11) DEFAULT NULL,
  `attendanceDaysAttended` int(11) DEFAULT NULL,
  `attendancePercentage` decimal(5,2) DEFAULT NULL,
  `internshipTitle` varchar(255) DEFAULT NULL,
  `internshipCompletionTitle` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `reportingManager` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `hideReportingManager` tinyint(1) NOT NULL DEFAULT 0,
  `hidePosition` tinyint(1) NOT NULL DEFAULT 0,
  `hideDepartment` tinyint(1) NOT NULL DEFAULT 0,
  `hideLocation` tinyint(1) NOT NULL DEFAULT 0,
  `wishMessage` text DEFAULT NULL,
  `signatureImage` varchar(500) DEFAULT NULL,
  `serialNumber` varchar(100) NOT NULL,
  `qrCode` text DEFAULT NULL,
  `createdAt` datetime NOT NULL DEFAULT current_timestamp(),
  `updatedAt` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certificates`
--

INSERT INTO `certificates` (`id`, `studentName`, `collegeName`, `fromDate`, `toDate`, `date`, `certificateTitle`, `projectTitle`, `certificateContent`, `signatoryTitle`, `attendanceTotalDays`, `attendanceDaysAttended`, `attendancePercentage`, `internshipTitle`, `internshipCompletionTitle`, `position`, `department`, `reportingManager`, `location`, `hideReportingManager`, `hidePosition`, `hideDepartment`, `hideLocation`, `wishMessage`, `signatureImage`, `serialNumber`, `qrCode`, `createdAt`, `updatedAt`) VALUES
(1, 'MS MATHAVI EDIT 1', 'Rani Anna Government College for Women, Tirunelveli', '2025-12-12', '2026-03-30', '2026-03-30', 'INTERNSHIP COMPLETION CERTIFICATE', 'ENTERPRISE WORKFLOW AUTOMATION SYSTEM', 'This is to certify that {{student Name}}, a student of {{college Name}} in M.Sc Computer Science, has successfully completed the internship on \"{{project Title}}\" under the guidance of PCS Software Solutions from {{from Date}} to {{to Date}}. The performance during this period was found to be satisfactory.', 'For PCS Software Solutions', 84, 73, 87.00, 'Internship cum College Project', 'Internship Completion Certificate', 'Intern – Project Trainee', 'Business Analyst', 'Surya G, Training Head', 'Surandai-Tenkasi, Tamil Nadu', 0, 0, 0, 0, 'We wish the student all the best in all future endeavours.', '/images/signature.png', 'PCS-2026-001', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUoAAAFKAQMAAABB54RGAAAABlBMVEX///8AAABVwtN+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAABnElEQVRoge2Ywa3EMAhEkVJASkrrKSkFrMTGMGB7oxxX5jBz4PvHz3tB4DEiFEX9SbtCZ/vv8PVHVC+R2PoQrYLi741u4KWtDD0nhGgF1DPZPx9XO9Q2zpb2k2hB1L4EcBck0dLoDTR5TpVoTRRAiy2ddxmKh/f+SnQRmoZkRy0O4c27EF2ETjIb4h4yi+9FRFeg3irNL27aK9CDRCMlWgTtt9uNoiphTdyVWLKJlkAljD3eYkix3W6//ZLoajQT2x5kXndHonPnJFoB9ew22e3mwTf2XBGtgAqKT7xpujCkch1KtBAaY18MO0ZX8vD5RJeiWWj2ctYwjTApe1gToiXQ4PEqu8bj48yeaAXUv2TTzEOSjTRrkeh6FHs9mLyH5q8RLYJ+5s9Y4WkWtp9oHfSMYUef/UoOQFTHiiW6FO2KauuHYE1+QaLLUM+fwi+m2Y8UE62FRjrP9Is4+Uws0QIo6k4wAIkUm6ZXHNFiqGfy4fOJlkM37WHYyAcA0QqoaeySu91zm44bREugqtOdFu7+yJAiuhylKOoP+gKtvqtCRfjcmAAAAABJRU5ErkJggg==', '2026-09-03 12:47:32', '2026-09-03 13:46:23'),
(2, 'MS XXX EDIT', 'Rani Anna Government College for Women, Tirunelveli', '2025-12-12', '2026-03-30', '2026-03-30', 'INTERNSHIP COMPLETION CERTIFICATE', 'ENTERPRISE WORKFLOW AUTOMATION SYSTEM', 'This is to certify that {{student Name}}, a student of {{college Name}} in M.Sc Computer Science, has successfully completed the internship on \"{{project Title}}\" under the guidance of PCS Software Solutions from {{from Date}} to {{to Date}}. The performance during this period was found to be satisfactory.', 'For PCS Software Solutions', 84, 73, 87.00, 'Internship cum College Project', 'Internship Completion Certificate', 'Intern – Project Trainee', 'Business Analyst', 'Surya G, Training Head', 'Surandai-Tenkasi, Tamil Nadu', 0, 0, 0, 0, 'We wish the student all the best in all future endeavours.', '/images/signature.png', 'PCS-2026-002', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUoAAAFKAQMAAABB54RGAAAABlBMVEX///8AAABVwtN+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAABoElEQVRoge2Zy23EMAxECbgAl+TWXZILMDBZ8ycqTo4L8TA8aGHp6URwNOSKMBiML8UOj1M2fD5vwbnrp0gc3US7oP47zuS4pOwNhGgHVFPn6ZwTm3tEu6GfMgSenD6JJdodzVq8YiHaD9XwJy6WcfNPfSW6CA3X4Xo5LR5Eu6AjrORgHlKON0B0ORqA5i+kUlFMtUi0CeqyuDsqYtZkK+0a0SZopnM8cVmQB9yuEG2Caue8efucPbTuaXbHHtHlqMyePpdHNO2dq48d0cVo5s/OxpAq9lI0iS5H92pD4OOqMCT4R1+JLkbDmjznOanCFYMroi1QiZzmSNGq0spQL836SnQ1KiJDL+soGPnsEe2AqkBmyZ2Wzs39iflKEO2CylacY+hl5YtoEl2NFkOCTKceuCEZQXQ5+uvSo5zu80eT9uKJLkItf6hTKfMntgBEO6H+G8qZtRiJnUST6HIU2T672Udc0qqsiSXaBY1eLPozPZ5mxUT7oHvyeL9zRLugGmYf0+x7VQJzYokuRl0bi9nXsL/CcIeGEu2AMhiML8QPNLwFUKLR/iwAAAAASUVORK5CYII=', '2026-09-03 13:46:43', '2026-09-03 13:47:57'),
(3, 'YYY', 'Rani Anna Government College for Women, Tirunelveli', '2025-12-12', '2026-03-30', '2026-03-30', 'INTERNSHIP COMPLETION CERTIFICATE', 'ENTERPRISE WORKFLOW AUTOMATION SYSTEM', 'This is to certify that {{student Name}}, a student of {{college Name}} in M.Sc Computer Science, has successfully completed the internship on \"{{project Title}}\" under the guidance of PCS Software Solutions from {{from Date}} to {{to Date}}. The performance during this period was found to be satisfactory.', 'For PCS Software Solutions', 84, 73, 87.00, 'Internship cum College Project', 'Internship Completion Certificate', 'Intern – Project Trainee', 'Business Analyst', 'Surya G, Training Head', 'Surandai-Tenkasi, Tamil Nadu', 0, 0, 0, 0, 'We wish the student all the best in all future endeavours.', '/images/signature.png', 'PCS-2026-003', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUoAAAFKAQMAAABB54RGAAAABlBMVEX///8AAABVwtN+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAABnklEQVRoge2Zza3EIAyELaWALYnWtyQKiOQXjMcY5V1X+DA+kAQ+TiP/RoRGo/3IPur2lUufz1v0+7FPERzdRKug/lxn0rqkvYUQrYCadC7nLmzsEa2GPm6oOjQdwhKtjsLvDNVOtCRq5ikOS7r5X3wleghF1eHxclvciFZBl02X01lDSnsDRI+jAEw/hEpDdfNFokXQKWIkNpFZmlypXSNaBkXQVKS4cMimXq4QrYFKLhpXD/28ubppj+hpdBX75m2xjKDp/pmGVETPorO6D2F1DamGpqopaBItgbZopJfEbYbSLWgSPY2aG67YaBkvJlXaMbgiWgP1M++cAbji0zVvokVQeWmaR8EaaY9oBRQVCOa8dvPysW/rHlKJ1kBxNj+84s/8CppEj6NIcWnEkbwy9dBEC6Dp0iwYkd0iXrY3T/QQmoZUvr39YVElWgn1J8Ye+RKcVIjWQdXb5yFvF3TO4ZVZWKJVUJT96M/sOFoBorVQ88A1SNzzHNEqqBl6MZFc56vuwhI9jHpsRIpDVTl/hemNGEq0Akqj0X5gf2PTfGHN2XzmAAAAAElFTkSuQmCC', '2026-09-03 13:46:53', '2026-09-03 13:46:53'),
(4, 'HLO', 'Rani Anna Government College for Women, Tirunelveli', '2025-12-12', '2026-03-30', '2026-03-30', 'INTERNSHIP COMPLETION CERTIFICATE', 'ENTERPRISE WORKFLOW AUTOMATION SYSTEM', 'This is to certify that {{student Name}}, a student of {{college Name}} in M.Sc Computer Science, has successfully completed the internship on \"{{project Title}}\" under the guidance of PCS Software Solutions from {{from Date}} to {{to Date}}. The performance during this period was found to be satisfactory.', 'For PCS Software Solutions', 84, 73, 87.00, 'Internship cum College Project', 'Internship Completion Certificate', 'Intern – Project Trainee', 'Business Analyst', 'Surya G, Training Head', 'Surandai-Tenkasi, Tamil Nadu', 0, 0, 0, 0, 'We wish the student all the best in all future endeavours.', '/images/signature.png', 'PCS-2026-004', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAUoAAAFKAQMAAABB54RGAAAABlBMVEX///8AAABVwtN+AAAACXBIWXMAAA7EAAAOxAGVKw4bAAABoklEQVRoge2Zwa2EMAxEI1EAJdE6JVEAkjexPXZgv/5tFR9mDiyEx2nWg2NaoyjqR9rFdbZN+uXd5Nz1sjXcuolWQf23A/3skDhcY+2BEK2AqnVmp5lo7obFRAuivQxFLj24p0TrorayCZ4kWhJV6XKPyk1A3f/kK9FFqLjOKSpxcBGtgqaGsWHifPYtootQK77R2E/9YqyN+Bw3iNZAhw4UGpbRmsR2jWgNdHfrPDlboKn4DxBdjibgMjsPe3IjWgnFvblV3HX2MZIzpiBEa6Cbvc5a7MowpMJliuhqVJsP5KVvmnOTts/GEl2ODkW12ZxDU9JbyldoEl2LWkMSHQjOvAyvLFKiBVC0iq/WRCwvMQAhWgPNZv+KzjHzUo0VolVQ8FZtfm/4bHtoNZ1oFRT+eUCKZ2hSWZpEl6OTuzJ7eiA0X2VIdCX6+Lgytf3madQn0Rqou5ajKVgcxhKthLqJGB+Kd45u+Kt3IVoDzZcdXmz2diNaEW0x54Cx7Y+tGdHFqOoxn/KtmZfhd74SXYV6Nk6zX38c38OEaBmUoqgf6AOM4x6ColwW1QAAAABJRU5ErkJggg==', '2026-09-03 13:48:08', '2026-09-03 13:48:08');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token_hash` varchar(64) NOT NULL COMMENT 'SHA-256 hash of the session token',
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `token_hash`, `expires_at`, `created_at`, `updated_at`, `ip_address`, `user_agent`) VALUES
(1, 1, '5aacccbdc7df4b9d9ad63cbbf84aa5ea02299cdd06eefbd7f5e25a4bfd0ad5f3', '2026-09-04 09:12:58', '2026-09-03 12:42:58', '2026-09-03 12:42:58', '192.168.1.7', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'pcs', 'mathavikanagaraj1@gmail.com', '$2y$10$u1laWXaeNzwUqsJ.EMETp.NrM.44CO4CBVTK/9xUiArVV6m0iAybq', 'admin', '2026-09-03 07:12:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `certificates`
--
ALTER TABLE `certificates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_serialNumber` (`serialNumber`),
  ADD KEY `idx_certificateTitle` (`certificateTitle`),
  ADD KEY `idx_createdAt` (`createdAt`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_token_hash` (`token_hash`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_email` (`email`),
  ADD KEY `idx_role` (`role`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `certificates`
--
ALTER TABLE `certificates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
